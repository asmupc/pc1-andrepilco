#include"Controladora.h"
#include<iostream>
#include<Windows.h>
#include<vector>
using namespace std;

void main() {
	srand(time(NULL));
	Controladora c;
	c.Inicio();
	
}