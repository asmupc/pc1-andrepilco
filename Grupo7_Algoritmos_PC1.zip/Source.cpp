#include"Controladora.h"
#include<iostream>
#include<Windows.h>
#include<vector>
using namespace std;

void main() {
	Controladora c;
	c.Inicio();
	
}